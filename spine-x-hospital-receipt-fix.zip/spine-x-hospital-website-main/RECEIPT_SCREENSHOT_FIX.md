# Payment receipt screenshot preview fix

## Change
- Admin payment receipt preview now prefers `screenshotDataUrl` (the compressed image generated directly from the patient's selected file) over `screenshotUrl` (the Firebase Storage download URL).
- This prevents a stale or mismatched Storage URL from overriding the actual uploaded receipt in the admin preview.

## Important limitations
- This is a targeted UI fix based on the current source fields. It does not prove the Firestore record contains the patient's selected receipt.
- If the preview still shows the QR code after this change, inspect the payment document's `screenshotDataUrl` and `screenshotUrl` fields and verify the upload flow is writing the selected receipt. Do not manually approve payment until the actual receipt is visible and reconciled with the Fonepay statement.
- No production Firebase rules, credentials, or live deployment were changed.
